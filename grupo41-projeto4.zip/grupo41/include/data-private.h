/*
Grupo 41
Alexandre Chícharo 47815
Bruno Andrade 47829
Ricardo Cruz 47871
*/
#ifndef _DATA_PRIVATE_H
#define _DATA_PRIVATE_H

#include "data.h"

struct data_t *data_create_empty();

#endif